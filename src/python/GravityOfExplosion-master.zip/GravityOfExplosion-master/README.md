GravityOfExplosion
===========

AutoRigging System

This is a modular based auto rigging system, based on a flexibe framework 
given the user the opportunity using different languages to extend the system.

This core system will contain in future several sub-systems like PandorasBox,
which is the acutal rigging system. The user can develop further sub systems
on top by making use of the vast range of tools.

Due to the fact that this system is at its beginnings, it will take time till
it reaches a production ready stability.

Till then, happy escalation.

Cheerio
Emre Tekinalp
